

/**
 * Escriviu aquí una descripcìó de la classe DNI
 * 
 * @author (el vostre nom) 
 * @version (un número de versió o la data)
 */
public class DNI {
    
    
    private String numero;
    private char letra;
    
    private static char[] letters = {'T','R','W','A','G','M','Y','F',
        'P','D','X','B','N','J','Z','S','Q','V','H','L','C','K','E'};


public DNI(){
    numero = numero;
    letra = letra;
}

public DNI(String numero){
    this.numero = numero;
    
    int resto = Integer.parseInt(numero)%23;
    
    letra=letters[resto];
}

public DNI (String numero, char letra){
    this.numero = numero;
    this.letra = letra;
}


public boolean isDNICorrect(){
    int resto = Integer.parseInt(numero)%23;
    
    if (letters[resto]==letra){
     return true;   
    }else return false;
}

public String getNumero(){
    return numero;
}

public char getLetra(){
    return letra;
}

public void setNumero(String newNumber){
    numero=newNumber;
    
    int resto = Integer.parseInt(numero)%23;
    
    letra=letters[resto];
}

public void printDni(){
    System.out.println("Tu dni es: " +numero +letra);
}
}