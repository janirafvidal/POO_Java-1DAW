

/**
 * Escriviu aquí una descripcìó de la classe reproductor
 * 
 * @author (Janira) 
 * @version (un número de versió o la data)
 */
public class reproductor {

    // Variables d'instància. Canvieu l'exemple d'aquí sota pels vostres exemples
    private MusicOrganizer reproductor;

    /**
     * Mètode constructor per a objectes de la classe reproductor
     */
    public reproductor() {
       reproductor = new MusicOrganizer();
       reproductor.addFile("cancion1");
       reproductor.addFile("cancion2");
       reproductor.addFile("cancion3");
       reproductor.listFile(0);
       reproductor.listFile(1);
       reproductor.listFile(2);
       reproductor.removeFile(1);
       reproductor.listFile(0);
       reproductor.listFile(1);
       
    }

    
    
    
}
