import java.util.ArrayList;
import java.util.Iterator;

/**
 * Escriviu aquí una descripcìó de la classe App
 * 
 * @author (el vostre nom) 
 * @version (un número de versió o la data)
 */
public class App {

    private ArrayList<Post> posts;

    /**
     * Mètode constructor per a objectes de la classe App
     */
    public App() {
        posts = new ArrayList<Post>();
    }

    public void showPosts () {
        for(Post post : posts){
            System.out.println(post);
        }
    }
    
    public void addPost(Post post){
        posts.add(post);
    }
    
    public void lookForPostByUser(String user){
        for (Post post : posts){
            if (post.getUser()==user){
                
                System.out.println(post);
            }
        }
    }
    
    public void lookForPostByDate(String date){
        for (Post post : posts){
            if (post.getDate()==date){
                System.out.println(post);
            }
        }
    }
    
    public void deletePost(String user){
        Iterator<Post> it = posts.iterator();
        while(it.hasNext()){
            Post post = it.next();
            if(post.getUser().equals(user)){
             it.remove();   
            }
        }
    }
    
}
