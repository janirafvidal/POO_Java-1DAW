

/**
 * Escriviu aquí una descripcìó de la classe PicPost
 * 
 * @author (el vostre nom) 
 * @version (un número de versió o la data)
 */
public class PicPost extends Post{

    // Variables d'instància. Canvieu l'exemple d'aquí sota pels vostres exemples

    private String imgName;

    /**
     * Mètode constructor per a objectes de la classe PicPost
     */
    public PicPost(String text, String imgName, String user) {
        super(text,user);
        this.imgName=imgName;

    }

    public String getImgName(){
        return imgName;
    }
    
    public String toString(){
        return super.toString() +"\nNombre de la imagen: " +imgName;
    }
}
