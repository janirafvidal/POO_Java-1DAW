

/**
 * Escriviu aquí una descripcìó de la classe TextPost
 * 
 * @author (el vostre nom) 
 * @version (un número de versió o la data)
 */
public class TextPost extends Post
 {
    private String text;
    /**
     * Mètode constructor per a objectes de la classe TextPost
     */
    public TextPost(String text, String user, String date) {
        super(user,date);
        this.text = text;
    }

    public String toString(){
        String texto = super.toString();
        texto += "\nTexto: " +this.text;
        return texto;
    }
    
    public String getText(){
        return this.text;
    }
}
