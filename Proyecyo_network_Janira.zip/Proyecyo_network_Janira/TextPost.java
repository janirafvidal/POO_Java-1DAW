

/**
 * Escriviu aquí una descripcìó de la classe TextPost
 * 
 * @author (el vostre nom) 
 * @version (un número de versió o la data)
 */
public class TextPost extends Post
 {

    /**
     * Mètode constructor per a objectes de la classe TextPost
     */
    public TextPost(String text, String user) {
        super(text,user);
    }

    public String toString(){
        return super.toString();
    }
}
