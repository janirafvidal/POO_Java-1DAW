

/**
 * Escriviu aquí una descripcìó de la classe InstaJanExample
 * 
 * @author (el vostre nom) 
 * @version (un número de versió o la data)
 */
public class InstaJanExample {

    public App instagram;
    
    public TextPost text1;
    public TextPost text2;
    
    public PicPost img1;
    public PicPost img2;

    /**
     * Mètode constructor per a objectes de la classe InstaJanExample
     */
    public InstaJanExample() {
        this.instagram = new App();
        
        this.text1 = new TextPost("this is text", "user1", "13/20");
        this.text2 = new TextPost("this is text", "user3", "12/20");
        
        this.img1 = new PicPost("title", "img.png", "user1", "12/20");
        this.img2 = new PicPost("title", "img.png", "user5", "12/20");
        
        instagram.addPost(text1);
        instagram.addPost(text2);    
        instagram.addPost(img1);
        instagram.addPost(img2);
        
        instagram.lookForPostByDate("13/20");
        instagram.lookForPostByUser("user1");
        
        instagram.showPosts();
        
    }
    
}
