

/**
 * Escriviu aquí una descripcìó de la classe Post
 * 
 * @author (el vostre nom) 
 * @version (un número de versió o la data)
 */
public abstract class Post{

    private String text;
    private String user;

    /**
     * Mètode constructor per a objectes de la classe Post
     */
    public Post(String text, String user) {
        this.text=text;
        this.user=user;
    }
   
    public String getText(){
        return this.text;
    }
    
    public String getUser(){
        return this.user;
    }
    
    public String toString(){
        return ("Contenido del texto: " +text +"\nNombre del usuario: " +user);
    }
    
}
