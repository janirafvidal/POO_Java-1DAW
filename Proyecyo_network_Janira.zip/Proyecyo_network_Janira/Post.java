import java.util.ArrayList;

/**
 * Escriviu aquí una descripcìó de la classe Post
 * 
 * @author (el vostre nom) 
 * @version (un número de versió o la data)
 */
public abstract class Post{
    private String user;
    private int likes;
    private String date;
    private ArrayList<String> comments;

    /**
     * Mètode constructor per a objectes de la classe Post
     */
    public Post(String user, String date) {
        this.user=user;
        this.likes = 0;
        this.date = date;
        this.comments = new ArrayList<String>();
    }

    public String getUser(){
        return this.user;
    }
    
    public String toString(){
        return ("\nNombre del usuario: " +user +"\nFecha: " +date +"\nLikes: " +likes);
    }
    
    public int getLikes(){
        return this.likes;
    }
    
    public String getDate(){
        return this.date;
    }
    
    public void like(){
        likes++;
        System.out.println("Your post has " +likes +" likes!!");
    }   
    
    public void addComment(String comentario){
        comments.add(comentario);
    }
    
    public void getAllComments(){
        System.out.println("\nPost by: " +user +"\nDate: " +date +"\nLikes: " +likes +"\nComments: ");
        for (String comment : comments){
            System.out.println(comment);
        }
    }
    
    
}
