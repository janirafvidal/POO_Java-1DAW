

/**
 * Escriviu aquí una descripcìó de la classe Heater
 * 
 * @author (el vostre nom) 
 * @version (un número de versió o la data)
 */
public class Heater {

    // Variables d'instància. Canvieu l'exemple d'aquí sota pels vostres exemples
    private double temperature;
    private double min;
    private double max;
    private double increment;

    /**
     * Mètode constructor per a objectes de la classe Heater
     */
    public Heater(double temperatureMin, double temperatureMax) {
        // Heu d'inicialitzar les variables d'instància
        temperature = 15.0;
        increment = 5.0;
        min = temperatureMin;
        max = temperatureMax;
    }

    /**
     * warmer aumenta la temperatura en 5º
     */
    public void warmer () {
        temperature+=increment;
        if (temperature>max){
            temperature=max;
        }
    }
    
    /**
     * cooler aumenta la temperatura en 5º
     */
    public void cooler () {
        temperature-=increment;
        if (temperature<min){
            temperature=min;
        }
    }
    
    /**
     * devuelve el valor de la temperatura
     */
    public double getTemperature () {
        return temperature;
    }
    
    /**
     * asigna valor al incremento, puede ser un valor entre 1.0 y 5.0
     */
    public void setIncrement (double incremento) {
        increment=incremento; 
    }
}
