/**
 * Store details of club memberships.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
import java.util.ArrayList;
import java.util.Iterator;
public class Club
{
    private ArrayList<Membership> miembros ;
    
    /**
     * Constructor for objects of class Club
     */
    public Club()
    {
        miembros = new ArrayList<Membership>();
        
    }

    /**
     * Add a new member to the club's list of members.
     * @param member The member object to be added.
     */
    public void join(Membership member)
    {
        miembros.add(member);
    }

    /**
     * @return The number of members (Membership objects) in
     *         the club.
     */
    public int numberOfMembers()
    {
        return miembros.size();
    }
    
    /**
     *Determinar el número de miembros que se han unido en el mes indicado
     *@param month El mes que nos interesa
     *@return El número de miembros que se han unido ese mes
     */
    public int joinedInMonth(int month){
        int membersThisMonth=0;
        if (month < 0 || month > 12){
            System.out.println("Mes no valido");
            return 0;
        }else {
        for (Membership miembro : miembros){
            if(miembro.getMonth()==month){
                membersThisMonth++;
            }
        }
        return membersThisMonth;
    }
    }
    
    public int purgue(int month){
        int deletedMembers=0;
    
        if (month < 0 || month > 12){
            System.out.println("Mes inexistente");
            return 0;
        }else {
         Iterator<Membership> it = miembros.iterator();
          while(it.hasNext()){
             Membership miembros = it.next();
             if (miembros.getMonth() == month){
                it.remove();
                deletedMembers++;
            }
            }
            return deletedMembers;
        }
        
      }
        
}
