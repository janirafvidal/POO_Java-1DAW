

/**
 * Escriviu aquí una descripcìó de la classe AuctionExample
 * 
 * @author (el vostre nom) 
 * @version (un número de versió o la data)
 */
public class AuctionExample {

    private Person person1; 
    private Person person2;
    private Person person3;
    
    private Auction subasta;
    
    /**
     * Mètode constructor per a objectes de la classe AuctionExample
     */
    public AuctionExample() {
       person1 = new Person("Jan");
       person2 = new Person("Jan2");
       person3 = new Person("Jan3");   
       
       
       subasta = new Auction();
       subasta.enterLot("lote 1");
       subasta.enterLot("lote 2");
       subasta.enterLot("lote no deseado");
       
       subasta.showLots();
       
       subasta.makeABid(1, person1, 100l);
       subasta.makeABid(1, person2, 200l);
       subasta.makeABid(1, person3, 250l);
       subasta.makeABid(2, person3, 252l);
       
       subasta.removeLot(3);
       subasta.showLots();
       
       subasta.close();
       
    }
    
    
}
