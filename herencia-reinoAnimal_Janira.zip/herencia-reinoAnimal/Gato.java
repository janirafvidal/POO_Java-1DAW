

/**
 * Escriviu aquí una descripcìó de la classe Gato
 * 
 * @author (el vostre nom) 
 * @version (un número de versió o la data)
 */
public class Gato extends Mamifero implements Jugar{

    /**
     * Mètode constructor per a objectes de la classe Gato
     */
    public Gato(String nombre) {
        super(nombre);
    }

    /**
     * comunicacion
     */
    public void comunicarse () {
        System.out.println("Miaaau, miaaaau");
        super.comunicarse();
    }
    
    public void jugarConOvillos(){
     System.out.println("Miaaaau, me gusta jugar con los ovillos");   
    }
    
    public void saltaPorElAro(){
        System.out.println("Se jugar a saltar por el aro");
    }
    
    public void persigueUnObjeto(String objeto){
        System.out.println("Se jugar a perseguir un " +objeto);
    }
}
