

/**
 * Escriviu aquí una descripcìó de la classe Pez
 * 
 * @author (el vostre nom) 
 * @version (un número de versió o la data)
 */
public class Pez extends Animal{


    /**
     * Mètode constructor per a objectes de la classe Pez
     */
    public Pez(String nombre) {
        super(nombre);
    }

    
    public void respirar(){
     System.out.println("Respiro por las branquias");   
    }
    
    
    public void moverse(){
     System.out.println("Nado con aletas");   
    }
}
