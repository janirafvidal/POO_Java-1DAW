

/**
 * Escriviu aquí una descripcìó de la interfície Jugar
 * 
 * @author (el vostre nom) 
 * @version (un número de versió o la data)
 */
public interface Jugar {

    void saltaPorElAro();
    
    void persigueUnObjeto(String objeto);
}
