

/**
 * Escriviu aquí una descripcìó de la classe Perro
 * 
 * @author (el vostre nom) 
 * @version (un número de versió o la data)
 */
public class Perro extends Mamifero{

    /**
     * Mètode constructor per a objectes de la classe Perro
     */
    public Perro(String nombre) {
        super (nombre);
    }

    /**
     * comunicacion
     */
    public void comunicarse () {
        System.out.println("¡¡Guau, guau!!");
    }
    
    public void traerZapatillas (){
     System.out.println("Guau! Tus zapatillas. Te apestan los pies! Guau!");   
    }
}
