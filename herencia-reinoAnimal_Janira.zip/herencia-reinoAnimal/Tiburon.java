

/**
 * Escriviu aquí una descripcìó de la classe Tiburon
 * 
 * @author (el vostre nom) 
 * @version (un número de versió o la data)
 */
public class Tiburon extends Pez implements Jugar{

    // Variables d'instància. Canvieu l'exemple d'aquí sota pels vostres exemples
    private int x;

    /**
     * Mètode constructor per a objectes de la classe Tiburon
     */
    public Tiburon(String nombre) {
        super(nombre);
    }

    public void comunicarse(){
     System.out.println("Arqueo mi cuerpo para comunicarme");   
    }
    
    public void saltaPorElAro(){
        System.out.println("Se jugar a saltar por el aro");
    }
    
    public void persigueUnObjeto(String objeto){
        System.out.println("Se jugar a perseguir un " +objeto);
    }
    
}
