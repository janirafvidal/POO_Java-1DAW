

/**
 * Escriviu aquí una descripcìó de la classe PezPayaso
 * 
 * @author (el vostre nom) 
 * @version (un número de versió o la data)
 */
public class PezPayaso extends Pez{

    /**
     * Mètode constructor per a objectes de la classe PezPayaso
     */
    public PezPayaso(String nombre) {
        super(nombre);
    }

    
    public void comunicarse(){
     System.out.println("Me comunico haciendo burbujitas");   
    }
}
