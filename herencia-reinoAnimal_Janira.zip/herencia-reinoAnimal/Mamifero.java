    
    
    /**
     * Escriviu aquí una descripcìó de la classe Animales
     * 
     * @author (el vostre nom) 
     * @version (un número de versió o la data)
     *
    **
     * Esta clase da cierta funcionalidad para un Mamifero que tiene un nombre y sabe hacer ciertas cosas!
     */
    public abstract class Mamifero extends Animal
    {
        

    /**
     * Constructor para objetos de la clase Mamifero
     */
    public Mamifero(String nombre)
    {
        super(nombre);
    }

    
    /**
     * El método respirar es común para el gato y el perro
     * 
     */
    public void respirar()
    {
        System.out.println("Respiro aire por los pulmones");
    }    

    /**
     * El método moverse es común para el gato y el perro
     * 
     */
    public void moverse()
    {
        System.out.println("Me muevo a 4 patas");
    }    

    /**
     * El método mamar es común para el gato y el perro
     * 
     */
    public void mamar()
        {
            System.out.println("Cuando soy pequeño mamo");
        }    
     
}
