

/**
 * Escriviu aquí una descripcìó de la classe Entrenador
 * 
 * @author (el vostre nom) 
 * @version (un número de versió o la data)
 */
public class Entrenador extends Mamifero{

    /**
     * Mètode constructor per a objectes de la classe Entrenador
     */
    public Entrenador(String nombre) {
        super (nombre);
    }

    public void entrenar(Jugar animalQueSabeJugar){
        animalQueSabeJugar.saltaPorElAro();
    }
    
    public void dejarEntrar(Animal animal){
     if(animal instanceof Jugar){
         System.out.println("Pasa y te entreno");
        }else{
            System.out.println("Como no sabes jugar no puedo entrenarte");
        }
    }
}
