/**
 * A class that maintains information on a book.
 * This might form part of a larger application such
 * as a library system, for instance.
 *
 * @author (Insert your name here.)
 * @version (Insert today's date here.)
 */
class Book
{
    // The fields.
    private String author;
    private String title;
    private int pages;
    private String refNumber;
    private int borrowed;
    private boolean courseText;

    /**
     * Set the author and title fields when this object
     * is constructed.
     */
    public Book(String bookAuthor, String bookTitle, int bookPages, boolean isCourseText)
    {
        author = bookAuthor;
        title = bookTitle;
        pages = bookPages;
        refNumber = "";
        courseText = isCourseText;
        
        
    }

    public String getAuthor(){
        return author;
    }
    
    public String getTitle(){
        return title;
    }
        
    public int getPages(){
        return pages;
    }
    
    public void printAuthor(){
        System.out.println("El autor del libro se llama " +author);
    }
    
    
    public void printTitle(){
        System.out.println("El libro se llama " +title);
    }
    
    
    public void setRefNumber(String ref){
        if (ref.length() > 3){
            refNumber=ref;
            System.out.println("Nueva referencia");
        }else{
            System.out.println ("Referencia incorrecta");
        }
    }
    
    
    public String getRefNumber(){
        return refNumber;
    }
    
    public int getBorrowed(){
        borrowed++;
        return borrowed;
    }
    
    public boolean isCourseText(){
        if (courseText){
        return true;
        }else {
            return false;
        }
    }
    
    public void printDetails(){
        System.out.println("AUTOR: " +author);
        System.out.println("TITULO: " +title);
        System.out.println("Nº PAGINAS: " +pages);
        System.out.println("REFERENCIA: " +refNumber);
        System.out.println("Nº PRESTACIONES: " +borrowed);
        
        if (courseText){
        System.out.println("ES LIBRO DE TEXTO");
    }else {
        System.out.println("NO ES LIBRO DE TEXTO");
    }
}
}
