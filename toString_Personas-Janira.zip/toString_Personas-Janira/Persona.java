

/**
 *Janira
 */
public class Persona {

    // Variables d'instància. Canvieu l'exemple d'aquí sota pels vostres exemples
    private String nombre;
    private String apellidos;

    /**
     * Mètode constructor per a objectes de la classe Persona
     */
    public Persona(String nombre, String apellidos) {
        this.nombre = nombre;
        this.apellidos = apellidos;
    
    }

    
    public String getNombre () {
        return this.nombre;
    }
    
    
    public String getApellidos () {
        return this.apellidos;
    }
    
    //public String getDetails(){
    // return ("Nombres: " +nombre +" Apellidos: " +apellidos);   
    //}
    
    public String toString(){
     return ("Nombres: " +nombre +" Apellidos: " +apellidos);   
    }
}
