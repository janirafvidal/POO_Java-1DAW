import java.util.ArrayList;

/**
 * Escriviu aquí una descripcìó de la classe GestorPersonas
 * 
 * @author (el vostre nom) 
 * @version (un número de versió o la data)
 */
public class GestorPersonas {

    private ArrayList<Persona> personas;
    

    /**
     * Mètode constructor per a objectes de la classe GestorPersonas
     */
    public GestorPersonas() {
        personas = new ArrayList<>();
        addSamplePersons();
    }

    /**
     * Un exemple de mètode. Poseu-hi el vostre comentari
     * 
     * @param  y   Un paràmetre de mostra: ha de ser un nombre enter.
     * @return     La suma de x amb y 
     */
    public void addPersona(Persona persona) {
        personas.add(persona);
    }
    
    public void printAll(){
     for (Persona p:personas){
         //System.out.println(p.getDetails());
         System.out.println(p);
        }
    }
    
    public void addSamplePersons(){
     Persona jan;
     jan = new Persona("Janira", "Vidal");
     addPersona(jan);
     Persona alex;
     alex = new Persona("Alex", "V");
     addPersona(alex);
    }
}
